"""
==========================================================
Face3D Studio AI

Mesh Viewer

Autore:
Marco Cantù

Versione:
1.2.0
==========================================================
"""

import numpy as np
import pyqtgraph.opengl as gl

from PySide6.QtWidgets import QWidget, QVBoxLayout

from source.models.face_mesh import FaceMesh


class MeshViewer(QWidget):

    def __init__(self, parent=None):

        super().__init__(parent)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self._view = gl.GLViewWidget()
        layout.addWidget(self._view)

        #
        # Camera
        #

        self._view.setCameraPosition(
            distance=2.0,
        )

        #
        # Griglia
        #

        grid = gl.GLGridItem()

        grid.scale(
            0.1,
            0.1,
            0.1,
        )

        self._view.addItem(grid)

        #
        # Point cloud
        #

        self._points_item = None

        #
        # Parametri trasformazione
        #

        self.scale = 1.0

        self.tx = 0.0
        self.ty = 0.0
        self.tz = 0.0

        self.rx = 0.0
        self.ry = 0.0
        self.rz = 0.0

    # ---------------------------------------------------------

    def clear(self):

        if self._points_item is not None:

            self._view.removeItem(
                self._points_item
            )

            self._points_item = None

    # ---------------------------------------------------------

    def _rotate_x(self, points, angle):

        a = np.radians(angle)

        c = np.cos(a)
        s = np.sin(a)

        R = np.array(
            [
                [1, 0, 0],
                [0, c, -s],
                [0, s, c],
            ]
        )

        return points @ R.T

    # ---------------------------------------------------------

    def _rotate_y(self, points, angle):

        a = np.radians(angle)

        c = np.cos(a)
        s = np.sin(a)

        R = np.array(
            [
                [c, 0, s],
                [0, 1, 0],
                [-s, 0, c],
            ]
        )

        return points @ R.T

    # ---------------------------------------------------------

    def _rotate_z(self, points, angle):

        a = np.radians(angle)

        c = np.cos(a)
        s = np.sin(a)

        R = np.array(
            [
                [c, -s, 0],
                [s, c, 0],
                [0, 0, 1],
            ]
        )

        return points @ R.T

    # ---------------------------------------------------------

    def show_mesh(
        self,
        mesh: FaceMesh,
    ):

        self.clear()

        if mesh is None:
            return

        points = np.array(
            [
                [
                    v.x,
                    v.y,
                    v.z,
                ]
                for v in mesh.vertices
            ],
            dtype=float,
        )

        #
        # Trasformazioni
        #

        points *= self.scale

        points = self._rotate_x(points, self.rx)
        points = self._rotate_y(points, self.ry)
        points = self._rotate_z(points, self.rz)

        points[:, 0] += self.tx
        points[:, 1] += self.ty
        points[:, 2] += self.tz

        self._points_item = gl.GLScatterPlotItem(

            pos=points,

            size=6,

            color=(1.0, 1.0, 0.0, 1.0),

            pxMode=True,

        )

        self._view.addItem(
            self._points_item
        )