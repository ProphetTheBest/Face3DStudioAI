"""
==========================================================
Face3D Studio AI

Viewer Overlay

Autore:
Marco Cantù

Versione:
1.0.0
==========================================================
"""

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import QWidget

from source.ai.models.face_detection import FaceDetection


class ViewerOverlay(QWidget):

    def __init__(self, parent=None):

        super().__init__(parent)

        self._faces: list[FaceDetection] = []

        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)

        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)

        self.setStyleSheet("background: transparent;")

    # ---------------------------------------------------------

    def set_faces(
        self,
        faces: list[FaceDetection],
    ):

        self._faces = faces

        self.update()

    # ---------------------------------------------------------

    def clear(self):

        self._faces.clear()

        self.update()

    # ---------------------------------------------------------

    def paintEvent(self, event):

        super().paintEvent(event)

        painter = QPainter(self)

        pen = QPen(QColor(0, 255, 0))

        pen.setWidth(3)

        painter.setPen(pen)

        for face in self._faces:

            painter.drawRect(

                face.x,
                face.y,
                face.width,
                face.height,

            )